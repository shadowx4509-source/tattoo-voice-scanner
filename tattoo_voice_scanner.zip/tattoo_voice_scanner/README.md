# Tattoo Voice Scanner

A Flutter Android app that recognizes tattoos via the camera using classical
computer vision (ORB + AKAZE feature matching with homography verification)
and automatically plays a linked audio clip when a known tattoo is
recognized. Admins manage the tattoo library (image + audio + metadata)
through an in-app panel backed entirely by Supabase.

---

## 1. How recognition actually works (read this first)

This app uses **ORB and AKAZE feature detection** — classical, non-trained
computer vision algorithms — not a custom-trained deep learning tattoo
classifier. Concretely, for every tattoo in your library:

1. The reference image is downloaded once and its ORB + AKAZE keypoints/
   descriptors are computed and cached in memory.
2. Each live camera frame (throttled to ~4 fps, see `AppConstants
   .scannerFramesPerSecond`) is also run through ORB feature extraction.
3. Frame descriptors are matched against every reference tattoo's
   descriptors using a brute-force Hamming matcher + Lowe's ratio test.
4. If enough good matches exist, RANSAC fits a homography (a perspective
   transform) between the two sets of keypoints. If enough matches agree
   with one consistent transform (`minHomographyInliers`, default 10),
   the match is accepted as real — this is what makes the system robust
   to rotation, tilt, and different camera distances, and what rejects
   coincidental keypoint overlap between two unrelated tattoos.
5. Borderline matches get a second confirmation pass using AKAZE
   descriptors before being trusted.

**This works well when:** the tattoo has distinctive linework, shading, or
texture — i.e., enough local detail for ORB/AKAZE to find keypoints on.

**This struggles when:** the tattoo is a solid silhouette with very little
internal detail (e.g. a plain black heart), or lighting is drastically
different between the stored reference photo and the live scan. There's no
way around this with feature-matching — it's a property of the algorithm
class, not a bug. If this becomes a real problem in practice, the fix is a
trained deep-learning embedding model (e.g. a Siamese/triplet-loss network
fine-tuned on tattoo photos) — see the "Future improvements" section below;
that was intentionally not done here since it requires a labeled tattoo
dataset and training infrastructure outside the scope of this build.

TensorFlow Lite is wired into the project (`tflite_flutter` dependency) so
you have the hook to add such a model later, but no model file is bundled
since none was requested or available.

---

## 1a. IMPORTANT — verify the OpenCV API before your first build

I do not have a working Flutter/Dart environment or network access in the
environment that produced this code, so I could not run `flutter pub get`
or compile this project to confirm method signatures against the real
`opencv_dart` package. I was able to confirm one important fact via
documentation search: **`findHomography` returns a single `Mat` and takes
the inlier `mask` as an out-parameter you pass in**, not as part of a
returned tuple — `tattoo_matcher_engine.dart` has been written to match
that. I could **not** independently confirm the following, which are
written based on the package's typical/likely API surface but should be
checked the moment you run `flutter pub get`:

- `cv.ORB.create(nFeatures: ...)` / `cv.AKAZE.create()` — constructor
  names and named parameters
- `.detectAndCompute(mat, mask)` returning a `(VecKeyPoint, Mat)` record
- `cv.BFMatcher.create(type: cv.NORM_HAMMING)` and `.knnMatch(... k: 2)`
  returning `List<List<DMatch>>`
- `VecKeyPoint` indexing (`kp[i].pt.x` / `.pt.y`)
- `cv.Mat.fromList(...)` for building a point matrix from `List<List<double>>`

**Also note:** the OpenCV Flutter package itself has been migrating —
the current `opencv_dart` (2.x) is now a wrapper around a package called
`dartcv4`. The pubspec here pins `opencv_dart: ^2.0.0`, but you should run
`flutter pub get` and then `flutter pub outdated`, open whatever version
actually resolves, and skim its example/test files (or the generated docs
at `pub.dev/documentation/opencv_dart/latest/`) to confirm
`tattoo_matcher_engine.dart` compiles against it.

If `flutter pub get` / `flutter analyze` flags mismatches in this file
specifically, that's expected risk I'm flagging rather than a surprise —
fixing it should be a matter of adjusting method/parameter names to match
whatever the resolved version exposes; the matching *logic* (ratio test →
homography → inlier count) doesn't need to change, just the call syntax.

---

## 2. Tech stack

| Layer            | Choice                                   |
|-------------------|-------------------------------------------|
| Frontend          | Flutter (stable channel)                  |
| State management  | Riverpod                                  |
| Local cache       | Hive                                      |
| Backend           | Supabase only (Auth, Database, Storage)   |
| Computer vision   | OpenCV via `opencv_dart` (ORB, AKAZE, homography) |
| On-device ML hook | TensorFlow Lite via `tflite_flutter`      |
| Audio playback    | `just_audio`                              |

No Firebase, Appwrite, PocketBase, AWS, MongoDB, or any other backend is
used anywhere in this project.

---

## 3. Project structure

```
lib/
  core/
    constants/app_constants.dart      Supabase keys + all tunable thresholds
    theme/app_theme.dart              Material 3 light/dark theme
  data/
    models/tattoo_model.dart          Hive-backed model mirroring `tattoos` table
    services/
      supabase_service.dart           All Supabase auth/db/storage calls
      local_cache_service.dart        Hive read/write helpers
      tattoo_matcher_engine.dart      ORB/AKAZE/homography recognition engine
      audio_playback_service.dart     just_audio wrapper
  features/
    auth/
      screens/welcome_screen.dart     FIRST SCREEN — User Login / Admin Login only
      screens/user_login_screen.dart
      screens/admin_login_screen.dart
      providers/auth_providers.dart
    scanner/
      screens/scanner_screen.dart     Only screen a regular user ever sees
      widgets/tattoo_camera_view.dart Camera stream -> frame throttling -> matcher
      providers/scanner_provider.dart Orchestrates sync, matching, audio playback
    admin/
      screens/admin_panel_screen.dart List + delete tattoos
      screens/add_edit_tattoo_screen.dart Add/edit form with image+audio pickers
      providers/admin_providers.dart  CRUD against Supabase
  main.dart                           Entry point + cold-start routing logic

android/                              Full Android project (manifest, gradle, icons)
supabase/schema.sql                   Run this in Supabase SQL editor before first use
```

---

## 4. One-time Supabase setup

1. Open your project's SQL editor:
   `https://supabase.com/dashboard/project/nzgzrfgtyfkgfmqwaqfe/sql/new`
2. Paste the entire contents of `supabase/schema.sql` and run it. This creates:
   - `profiles` table (tracks admin status)
   - `tattoos` table (id, created_at, tattoo_name, tattoo_image, audio_url,
     shop_name, user_name — exactly the fields specified)
   - Row Level Security policies: anyone logged in can **read** tattoos
     (needed for the scanner); only admins can **write**.
   - Two public-read Storage buckets: `tattoo-images`, `tattoo-audio`.
3. Run the app once and sign up an account (User Login screen's "Sign up"
   link works fine for this — same backend as Admin Login).
4. In the Supabase dashboard, go to **Table Editor → profiles**, find your
   new user's row, and set `is_admin` to `true`.
5. That account can now log into the app via **Admin Login** and will land
   in the Admin Panel.

There is intentionally no in-app "become an admin" button — admin rights
are granted by you, the project owner, directly in the Supabase dashboard.

---

## 5. Local setup & running the app

### Prerequisites
- Flutter SDK (stable channel) — https://docs.flutter.dev/get-started/install
- Android Studio or just the Android SDK/command-line tools
- An Android device or emulator running **API 24 (Android 7.0) or higher**
  (minSdkVersion is 24, required by the camera and OpenCV plugins)
- A physical device is strongly recommended for testing the scanner — most
  emulators have weak/fake camera feeds that won't have real tattoo-like
  detail for ORB/AKAZE to latch onto.

### Steps

```bash
# 1. Get dependencies
flutter pub get

# 2. Generate the Hive adapter if you ever change TattooModel's fields
#    (a hand-written version is already checked in at
#    lib/data/models/tattoo_model.g.dart, so this is optional unless you
#    edit the model)
flutter pub run build_runner build --delete-conflicting-outputs

# 3. Confirm a device/emulator is attached
flutter devices

# 4. Run in debug mode
flutter run
```

If `flutter pub get` complains about `local.properties` or SDK paths,
delete `android/local.properties` and run `flutter run` once — Flutter
regenerates that file automatically with the correct paths for your machine.

---

## 6. Building a release APK

```bash
# Standard release APK (single file, works on most devices)
flutter build apk --release

# Output location:
# build/app/outputs/flutter-apk/app-release.apk
```

For a smaller, per-architecture build (recommended if distributing
directly rather than through Play Store):

```bash
flutter build apk --release --split-per-abi

# Produces:
# build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk
# build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
# build/app/outputs/flutter-apk/app-x86_64-release.apk
```

Install directly on a connected device:

```bash
flutter install
# or manually:
adb install build/app/outputs/flutter-apk/app-release.apk
```

### Before publishing to the Play Store

The current `android/app/build.gradle` release build uses **debug signing**
so you can produce a runnable APK immediately without setting up keys. For
an actual Play Store release, you must:

1. Generate a real upload keystore:
   ```bash
   keytool -genkey -v -keystore ~/tattoo-voice-upload-key.jks \
     -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```
2. Create `android/key.properties` (do NOT commit this file):
   ```
   storePassword=<your password>
   keyPassword=<your password>
   keyAlias=upload
   storeFile=/absolute/path/to/tattoo-voice-upload-key.jks
   ```
3. Update `android/app/build.gradle`'s `signingConfigs` block to read from
   `key.properties` instead of using `signingConfigs.debug`.
4. Build an app bundle instead of a raw APK for Play Store upload:
   ```bash
   flutter build appbundle --release
   ```

---

## 7. Permissions the app requests

| Permission | Why |
|---|---|
| `CAMERA` | Core scanning function |
| `INTERNET` / `ACCESS_NETWORK_STATE` | Supabase auth/database/storage |
| `READ_MEDIA_IMAGES` / `READ_MEDIA_AUDIO` (Android 13+) | Admin panel file pickers |
| `READ_EXTERNAL_STORAGE` (Android ≤12 only) | Same, for older OS versions |

No location, contacts, microphone, or background-data permissions are
requested anywhere in the app.

---

## 8. Error handling notes

- **Camera fails to initialize** (no camera, permission denied): scanner
  screen shows an inline error instead of crashing.
- **Supabase sync fails on scanner start** (no network): falls back to the
  last successfully cached tattoo list in Hive, if any; only shows a hard
  error if there's nothing cached yet.
- **A single tattoo's reference image fails to download**: that one tattoo
  is skipped during the matcher setup, the rest of the library still loads.
- **Admin upload fails partway** (e.g. image uploads but audio fails): the
  error is surfaced in the form; no database row is inserted unless both
  uploads succeed, so you won't end up with a tattoo record pointing at a
  missing file.
- **Editing a tattoo's image/audio**: the old Storage file is deleted only
  after the new one uploads successfully, and a failed delete (e.g.
  network hiccup) is treated as non-fatal — it won't block the edit, since
  an orphaned old file is a much smaller problem than losing the user's edit.

---

## 9. Known limitations / what to test before relying on this in production

- Recognition accuracy depends heavily on tattoo detail — test with your
  actual target tattoos, not just text/logos, before assuming it'll work
  for every style.
- The scanner currently checks every registered tattoo against every
  frame (`TattooMatcherEngine.matchFrame`). This is fine for a shop-sized
  library (tens of tattoos) but will need batching/indexing if you ever
  scale to hundreds+.
- No automated test suite is included — given the project's reliance on
  camera hardware and a live Supabase backend, meaningful tests would need
  mocked camera frames and a test Supabase project, which is a reasonable
  next step but wasn't in scope for this initial build.

---

## 10. Future improvements (not built, flagging for awareness)

- Swap/augment ORB+AKAZE with a trained embedding model (e.g. via TFLite)
  for better robustness on low-detail tattoos — requires a labeled dataset.
- Add a "last synced" indicator and manual refresh button visible to
  regular users (currently sync happens silently on scanner open).
- Add admin-side search/filter once the tattoo library grows large.
