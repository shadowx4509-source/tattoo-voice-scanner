-- ============================================================================
-- Tattoo Voice Scanner — Supabase schema
-- ============================================================================
-- Run this once in your Supabase project's SQL Editor
-- (https://supabase.com/dashboard/project/nzgzrfgtyfkgfmqwaqfe/sql/new)
--
-- This sets up:
--   1. profiles table (tracks which auth users are admins)
--   2. tattoos table (the core data: name, image, audio, shop, user)
--   3. Row Level Security policies for both
--   4. Storage buckets for tattoo images and audio
--
-- IMPORTANT: after running this, you must manually promote at least one
-- user to admin (see the bottom of this file) — there is no self-service
-- "become admin" flow in the app, by design.
-- ============================================================================


-- ----------------------------------------------------------------------------
-- 1. profiles table
-- ----------------------------------------------------------------------------
-- One row per auth user, created automatically on signup via trigger below.
-- is_admin defaults to false; you flip it to true manually for trusted
-- accounts only.

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Users can read their own profile (needed so the app can check is_admin).
create policy "Users can view their own profile"
  on public.profiles for select
  using (auth.uid() = id);

-- Nobody can self-promote to admin via the API — is_admin is only ever
-- changed by you, directly in the Supabase dashboard's table editor, or by
-- a service-role key, never by the anon/publishable key the app uses.
-- (No insert/update/delete policies are defined for normal users, so RLS
-- denies those by default.)

-- Auto-create a profile row whenever a new auth user signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


-- ----------------------------------------------------------------------------
-- 2. tattoos table
-- ----------------------------------------------------------------------------

create table if not exists public.tattoos (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  tattoo_name text not null,
  tattoo_image text not null,   -- public Storage URL
  audio_url text not null,      -- public Storage URL
  shop_name text not null default '',
  user_name text not null default ''
);

alter table public.tattoos enable row level security;

-- Anyone who is logged in (regular user or admin) can read the tattoo
-- library — the scanner needs this to download reference images.
create policy "Logged-in users can read tattoos"
  on public.tattoos for select
  using (auth.role() = 'authenticated');

-- Only admins can insert/update/delete tattoo records.
create policy "Admins can insert tattoos"
  on public.tattoos for insert
  with check (
    exists (
      select 1 from public.profiles
      where profiles.id = auth.uid() and profiles.is_admin = true
    )
  );

create policy "Admins can update tattoos"
  on public.tattoos for update
  using (
    exists (
      select 1 from public.profiles
      where profiles.id = auth.uid() and profiles.is_admin = true
    )
  );

create policy "Admins can delete tattoos"
  on public.tattoos for delete
  using (
    exists (
      select 1 from public.profiles
      where profiles.id = auth.uid() and profiles.is_admin = true
    )
  );


-- ----------------------------------------------------------------------------
-- 3. Storage buckets
-- ----------------------------------------------------------------------------
-- Two public-read buckets: tattoo-images and tattoo-audio. Public read is
-- required so the scanner can download reference images/audio via a plain
-- URL without re-authenticating per file. Writes are still admin-only.

insert into storage.buckets (id, name, public)
values ('tattoo-images', 'tattoo-images', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('tattoo-audio', 'tattoo-audio', true)
on conflict (id) do nothing;

-- Public read access for both buckets (needed for the scanner + admin
-- preview thumbnails to load via plain HTTPS URLs).
create policy "Public read access to tattoo images"
  on storage.objects for select
  using (bucket_id = 'tattoo-images');

create policy "Public read access to tattoo audio"
  on storage.objects for select
  using (bucket_id = 'tattoo-audio');

-- Only admins can upload/replace/delete files in either bucket.
create policy "Admins can upload tattoo images"
  on storage.objects for insert
  with check (
    bucket_id = 'tattoo-images'
    and exists (
      select 1 from public.profiles
      where profiles.id = auth.uid() and profiles.is_admin = true
    )
  );

create policy "Admins can upload tattoo audio"
  on storage.objects for insert
  with check (
    bucket_id = 'tattoo-audio'
    and exists (
      select 1 from public.profiles
      where profiles.id = auth.uid() and profiles.is_admin = true
    )
  );

create policy "Admins can delete tattoo images"
  on storage.objects for delete
  using (
    bucket_id = 'tattoo-images'
    and exists (
      select 1 from public.profiles
      where profiles.id = auth.uid() and profiles.is_admin = true
    )
  );

create policy "Admins can delete tattoo audio"
  on storage.objects for delete
  using (
    bucket_id = 'tattoo-audio'
    and exists (
      select 1 from public.profiles
      where profiles.id = auth.uid() and profiles.is_admin = true
    )
  );


-- ============================================================================
-- AFTER RUNNING THIS SCRIPT — promote your first admin:
-- ============================================================================
-- 1. Sign up once in the app using the "Admin Login" screen's sign-up flow
--    (or via the User Login screen — same backend), using the email you
--    want to use as admin.
-- 2. In the Supabase dashboard, go to Table Editor -> profiles.
-- 3. Find the row matching that user's email, edit it, and set
--    is_admin to true.
-- 4. That account can now log in via "Admin Login" in the app and will be
--    routed to the Admin Panel.
-- ============================================================================
