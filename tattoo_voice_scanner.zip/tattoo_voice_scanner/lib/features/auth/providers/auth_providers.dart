import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../data/services/supabase_service.dart';

/// Streams Supabase auth state so the UI can react to login/logout
/// immediately without manual polling.
final authStateProvider = StreamProvider<AuthState>((ref) {
  return SupabaseService.instance.authStateChanges;
});

/// Whether anyone is currently logged in (user or admin — same Supabase
/// auth backend, distinguished by the `profiles.is_admin` flag).
final isLoggedInProvider = Provider<bool>((ref) {
  final authState = ref.watch(authStateProvider);
  return authState.maybeWhen(
    data: (state) => state.session != null,
    orElse: () => SupabaseService.instance.isLoggedIn,
  );
});

/// Resolves whether the current user has admin privileges. Re-evaluated
/// whenever auth state changes.
final isAdminProvider = FutureProvider<bool>((ref) async {
  ref.watch(authStateProvider);
  if (!SupabaseService.instance.isLoggedIn) return false;
  return SupabaseService.instance.isCurrentUserAdmin();
});

enum AuthFormStatus { idle, loading, success, error }

class AuthFormState {
  final AuthFormStatus status;
  final String? errorMessage;

  const AuthFormState({
    this.status = AuthFormStatus.idle,
    this.errorMessage,
  });

  AuthFormState copyWith({AuthFormStatus? status, String? errorMessage}) {
    return AuthFormState(
      status: status ?? this.status,
      errorMessage: errorMessage,
    );
  }
}

/// Drives the login/signup form UI (loading spinner, error text) for the
/// regular user login screen.
class AuthFormController extends StateNotifier<AuthFormState> {
  AuthFormController() : super(const AuthFormState());

  Future<bool> signIn(String email, String password) async {
    state = state.copyWith(status: AuthFormStatus.loading);
    try {
      await SupabaseService.instance.signIn(email: email, password: password);
      state = state.copyWith(status: AuthFormStatus.success);
      return true;
    } catch (e) {
      state = state.copyWith(
        status: AuthFormStatus.error,
        errorMessage: _friendlyError(e),
      );
      return false;
    }
  }

  Future<bool> signUp(String email, String password) async {
    state = state.copyWith(status: AuthFormStatus.loading);
    try {
      await SupabaseService.instance.signUp(email: email, password: password);
      state = state.copyWith(status: AuthFormStatus.success);
      return true;
    } catch (e) {
      state = state.copyWith(
        status: AuthFormStatus.error,
        errorMessage: _friendlyError(e),
      );
      return false;
    }
  }

  String _friendlyError(Object e) {
    if (e is AuthException) return e.message;
    return 'Something went wrong. Please try again.';
  }

  void reset() => state = const AuthFormState();
}

final userAuthFormProvider =
    StateNotifierProvider.autoDispose<AuthFormController, AuthFormState>(
  (ref) => AuthFormController(),
);

final adminAuthFormProvider =
    StateNotifierProvider.autoDispose<AuthFormController, AuthFormState>(
  (ref) => AuthFormController(),
);
