import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/auth_providers.dart';
import '../../../data/services/supabase_service.dart';
import '../../admin/screens/admin_panel_screen.dart';

/// Admin login uses the same Supabase auth backend as regular users — the
/// distinction is the `is_admin` flag on that user's row in the `profiles`
/// table (see supabase/schema.sql). Granting admin rights is done by you,
/// the project owner, via the Supabase dashboard; there is no self-service
/// "become an admin" flow in the app.
class AdminLoginScreen extends ConsumerStatefulWidget {
  const AdminLoginScreen({super.key});

  @override
  ConsumerState<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends ConsumerState<AdminLoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  String? _accessDeniedMessage;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _accessDeniedMessage = null);

    final controller = ref.read(adminAuthFormProvider.notifier);
    final success = await controller.signIn(
      _emailController.text.trim(),
      _passwordController.text,
    );
    if (!success || !mounted) return;

    final isAdmin = await SupabaseService.instance.isCurrentUserAdmin();
    if (!mounted) return;

    if (!isAdmin) {
      await SupabaseService.instance.signOut();
      setState(() {
        _accessDeniedMessage =
            'This account does not have admin access.';
      });
      return;
    }

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const AdminPanelScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final formState = ref.watch(adminAuthFormProvider);
    final isLoading = formState.status == AuthFormStatus.loading;

    return Scaffold(
      appBar: AppBar(title: const Text('Admin Login')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 12),
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Admin Email',
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'Enter email';
                    if (!v.contains('@')) return 'Enter a valid email';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _passwordController,
                  obscureText: _obscurePassword,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      icon: Icon(_obscurePassword
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined),
                      onPressed: () => setState(
                          () => _obscurePassword = !_obscurePassword),
                    ),
                  ),
                  validator: (v) {
                    if (v == null || v.isEmpty) return 'Enter password';
                    return null;
                  },
                ),
                if (formState.status == AuthFormStatus.error) ...[
                  const SizedBox(height: 12),
                  Text(
                    formState.errorMessage ?? 'Login failed',
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  ),
                ],
                if (_accessDeniedMessage != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    _accessDeniedMessage!,
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  ),
                ],
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: isLoading ? null : _submit,
                  child: isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Login as Admin'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
