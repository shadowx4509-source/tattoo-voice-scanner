import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/app_constants.dart';
import '../../../data/models/tattoo_model.dart';
import '../../../data/services/local_cache_service.dart';
import '../../../data/services/supabase_service.dart';

enum AdminOpStatus { idle, loading, success, error }

class AdminTattooListState {
  final List<TattooModel> tattoos;
  final bool isLoading;
  final String? errorMessage;

  const AdminTattooListState({
    this.tattoos = const [],
    this.isLoading = false,
    this.errorMessage,
  });

  AdminTattooListState copyWith({
    List<TattooModel>? tattoos,
    bool? isLoading,
    String? errorMessage,
  }) {
    return AdminTattooListState(
      tattoos: tattoos ?? this.tattoos,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
    );
  }
}

/// Drives the admin panel's tattoo list — fetch, add, edit, delete — all
/// against Supabase directly (database + storage), per spec.
class AdminTattooController extends StateNotifier<AdminTattooListState> {
  AdminTattooController() : super(const AdminTattooListState()) {
    refresh();
  }

  final _service = SupabaseService.instance;
  final _cache = LocalCacheService.instance;

  Future<void> refresh() async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final tattoos = await _service.fetchAllTattoos();
      await _cache.replaceAllCachedTattoos(tattoos);
      state = state.copyWith(tattoos: tattoos, isLoading: false);
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to load tattoos: $e',
      );
    }
  }

  /// Uploads image + audio, then inserts the database row. Only one image
  /// and one audio file per tattoo, per spec — this method enforces that
  /// shape by construction (it only ever takes single files).
  Future<bool> addTattoo({
    required String tattooName,
    required File imageFile,
    required File audioFile,
    required String shopName,
    required String userName,
  }) async {
    try {
      final imageUrl = await _service.uploadTattooImage(imageFile);
      final audioUrl = await _service.uploadTattooAudio(audioFile);

      final tattoo = await _service.insertTattoo(
        tattooName: tattooName,
        tattooImageUrl: imageUrl,
        audioUrl: audioUrl,
        shopName: shopName,
        userName: userName,
      );

      await _cache.upsertCachedTattoo(tattoo);
      state = state.copyWith(tattoos: [tattoo, ...state.tattoos]);
      return true;
    } catch (e) {
      state = state.copyWith(errorMessage: 'Failed to add tattoo: $e');
      return false;
    }
  }

  /// Edits an existing tattoo. Image/audio files are optional — if not
  /// provided, the existing storage URLs are kept; if provided, the old
  /// file is deleted from storage and replaced.
  Future<bool> editTattoo({
    required TattooModel original,
    required String tattooName,
    required String shopName,
    required String userName,
    File? newImageFile,
    File? newAudioFile,
  }) async {
    try {
      String imageUrl = original.tattooImageUrl;
      String audioUrl = original.audioUrl;

      if (newImageFile != null) {
        final uploaded = await _service.uploadTattooImage(newImageFile);
        await _service.deleteStorageFileByUrl(
          original.tattooImageUrl,
          AppConstants.tattooImagesBucket,
        );
        imageUrl = uploaded;
      }

      if (newAudioFile != null) {
        final uploaded = await _service.uploadTattooAudio(newAudioFile);
        await _service.deleteStorageFileByUrl(
          original.audioUrl,
          AppConstants.tattooAudioBucket,
        );
        audioUrl = uploaded;
      }

      final updated = original.copyWith(
        tattooName: tattooName,
        tattooImageUrl: imageUrl,
        audioUrl: audioUrl,
        shopName: shopName,
        userName: userName,
      );

      final saved = await _service.updateTattoo(updated);
      await _cache.upsertCachedTattoo(saved);

      state = state.copyWith(
        tattoos: state.tattoos
            .map((t) => t.id == saved.id ? saved : t)
            .toList(),
      );
      return true;
    } catch (e) {
      state = state.copyWith(errorMessage: 'Failed to update tattoo: $e');
      return false;
    }
  }

  Future<bool> deleteTattoo(TattooModel tattoo) async {
    try {
      await _service.deleteTattoo(tattoo.id);
      await _service.deleteStorageFileByUrl(
        tattoo.tattooImageUrl,
        AppConstants.tattooImagesBucket,
      );
      await _service.deleteStorageFileByUrl(
        tattoo.audioUrl,
        AppConstants.tattooAudioBucket,
      );
      await _cache.deleteCachedTattoo(tattoo.id);

      state = state.copyWith(
        tattoos: state.tattoos.where((t) => t.id != tattoo.id).toList(),
      );
      return true;
    } catch (e) {
      state = state.copyWith(errorMessage: 'Failed to delete tattoo: $e');
      return false;
    }
  }
}

final adminTattooControllerProvider =
    StateNotifierProvider<AdminTattooController, AdminTattooListState>(
  (ref) => AdminTattooController(),
);
