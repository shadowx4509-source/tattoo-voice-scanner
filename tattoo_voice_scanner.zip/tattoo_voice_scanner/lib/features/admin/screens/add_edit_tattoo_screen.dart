import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import '../../../data/models/tattoo_model.dart';
import '../providers/admin_providers.dart';

/// Single screen used for both adding a new tattoo and editing an
/// existing one — only one image and one audio file per tattoo, per spec,
/// enforced here by the form simply only ever holding one of each.
class AddEditTattooScreen extends ConsumerStatefulWidget {
  final TattooModel? existingTattoo;
  const AddEditTattooScreen({super.key, this.existingTattoo});

  bool get isEditing => existingTattoo != null;

  @override
  ConsumerState<AddEditTattooScreen> createState() =>
      _AddEditTattooScreenState();
}

class _AddEditTattooScreenState extends ConsumerState<AddEditTattooScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _shopController;
  late final TextEditingController _userController;

  File? _pickedImage;
  File? _pickedAudio;
  String? _pickedAudioName;
  bool _isSaving = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    final existing = widget.existingTattoo;
    _nameController = TextEditingController(text: existing?.tattooName ?? '');
    _shopController = TextEditingController(text: existing?.shopName ?? '');
    _userController = TextEditingController(text: existing?.userName ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _shopController.dispose();
    _userController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery);
    if (file != null) {
      setState(() => _pickedImage = File(file.path));
    }
  }

  Future<void> _pickAudio() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
    );
    if (result != null && result.files.single.path != null) {
      setState(() {
        _pickedAudio = File(result.files.single.path!);
        _pickedAudioName = result.files.single.name;
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final isEditing = widget.isEditing;
    if (!isEditing && (_pickedImage == null || _pickedAudio == null)) {
      setState(() {
        _errorMessage = 'Please select both an image and an audio file.';
      });
      return;
    }

    setState(() {
      _isSaving = true;
      _errorMessage = null;
    });

    final controller = ref.read(adminTattooControllerProvider.notifier);
    bool success;

    if (isEditing) {
      success = await controller.editTattoo(
        original: widget.existingTattoo!,
        tattooName: _nameController.text.trim(),
        shopName: _shopController.text.trim(),
        userName: _userController.text.trim(),
        newImageFile: _pickedImage,
        newAudioFile: _pickedAudio,
      );
    } else {
      success = await controller.addTattoo(
        tattooName: _nameController.text.trim(),
        imageFile: _pickedImage!,
        audioFile: _pickedAudio!,
        shopName: _shopController.text.trim(),
        userName: _userController.text.trim(),
      );
    }

    if (!mounted) return;

    setState(() => _isSaving = false);

    if (success) {
      Navigator.of(context).pop();
    } else {
      setState(() {
        _errorMessage = ref.read(adminTattooControllerProvider).errorMessage ??
            'Failed to save tattoo.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final existing = widget.existingTattoo;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isEditing ? 'Edit Tattoo' : 'Add Tattoo'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _ImagePickerTile(
                  pickedImage: _pickedImage,
                  existingImageUrl: existing?.tattooImageUrl,
                  onTap: _pickImage,
                ),
                const SizedBox(height: 16),
                _AudioPickerTile(
                  pickedAudioName: _pickedAudioName,
                  hasExistingAudio: existing?.audioUrl.isNotEmpty ?? false,
                  onTap: _pickAudio,
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Tattoo Name'),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _shopController,
                  decoration: const InputDecoration(labelText: 'Shop Name'),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _userController,
                  decoration: const InputDecoration(labelText: 'User Name'),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                if (_errorMessage != null) ...[
                  const SizedBox(height: 14),
                  Text(
                    _errorMessage!,
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  ),
                ],
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: _isSaving ? null : _save,
                  child: _isSaving
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(widget.isEditing ? 'Save Changes' : 'Add Tattoo'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ImagePickerTile extends StatelessWidget {
  final File? pickedImage;
  final String? existingImageUrl;
  final VoidCallback onTap;

  const _ImagePickerTile({
    required this.pickedImage,
    required this.existingImageUrl,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget preview;
    if (pickedImage != null) {
      preview = ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Image.file(pickedImage!, fit: BoxFit.cover),
      );
    } else if (existingImageUrl != null && existingImageUrl!.isNotEmpty) {
      preview = ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Image.network(existingImageUrl!, fit: BoxFit.cover),
      );
    } else {
      preview = const Icon(Icons.add_photo_alternate_outlined, size: 36);
    }

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        height: 160,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(14),
        ),
        alignment: Alignment.center,
        child: preview,
      ),
    );
  }
}

class _AudioPickerTile extends StatelessWidget {
  final String? pickedAudioName;
  final bool hasExistingAudio;
  final VoidCallback onTap;

  const _AudioPickerTile({
    required this.pickedAudioName,
    required this.hasExistingAudio,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final label = pickedAudioName ??
        (hasExistingAudio ? 'Audio file already set (tap to replace)' : 'Select audio file');

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            const Icon(Icons.audiotrack_outlined),
            const SizedBox(width: 12),
            Expanded(
              child: Text(label, overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      ),
    );
  }
}
