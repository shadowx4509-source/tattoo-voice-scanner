import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/scanner_provider.dart';
import '../widgets/tattoo_camera_view.dart';

/// The only screen a regular user ever sees after logging in. Camera opens
/// automatically, scanning is continuous, and there is no scan/capture
/// button — recognition and audio playback are fully automatic per spec.
class ScannerScreen extends ConsumerWidget {
  const ScannerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scannerState = ref.watch(scannerControllerProvider);

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          const TattooCameraView(),

          // Subtle framing guide — not a capture button, just a visual aid
          // showing where to position the tattoo.
          if (scannerState.status == ScannerStatus.scanning)
            Center(
              child: Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.5),
                    width: 2,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),

          // Status pill at the top.
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: SafeArea(child: _StatusBanner(state: scannerState)),
          ),

          if (scannerState.status == ScannerStatus.syncingReferenceImages)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Colors.white),
                    SizedBox(height: 16),
                    Text(
                      'Loading tattoo library…',
                      style: TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),

          if (scannerState.status == ScannerStatus.error)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.cloud_off, color: Colors.white, size: 40),
                    const SizedBox(height: 12),
                    Text(
                      scannerState.errorMessage ?? 'Something went wrong.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white),
                    ),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: () =>
                          ref.read(scannerControllerProvider.notifier).resync(),
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _StatusBanner extends StatelessWidget {
  final ScannerState state;
  const _StatusBanner({required this.state});

  @override
  Widget build(BuildContext context) {
    final isMatch = state.status == ScannerStatus.matchFound;
    final label = isMatch
        ? (state.matchedTattoo?.tattooName ?? 'Tattoo recognized')
        : 'Scanning…';

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: isMatch
            ? Colors.green.withValues(alpha: 0.85)
            : Colors.black.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isMatch ? Icons.volume_up_rounded : Icons.camera_alt_outlined,
            color: Colors.white,
            size: 18,
          ),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: Colors.white)),
        ],
      ),
    );
  }
}
