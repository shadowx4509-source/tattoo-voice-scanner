import 'dart:async';
import 'dart:typed_data';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import '../../../core/constants/app_constants.dart';
import '../../../data/models/tattoo_model.dart';
import '../../../data/services/audio_playback_service.dart';
import '../../../data/services/local_cache_service.dart';
import '../../../data/services/supabase_service.dart';
import '../../../data/services/tattoo_matcher_engine.dart';

enum ScannerStatus {
  initializing,
  syncingReferenceImages,
  scanning,
  matchFound,
  error,
}

class ScannerState {
  final ScannerStatus status;
  final TattooModel? matchedTattoo;
  final String? errorMessage;
  final int referenceImageCount;

  const ScannerState({
    this.status = ScannerStatus.initializing,
    this.matchedTattoo,
    this.errorMessage,
    this.referenceImageCount = 0,
  });

  ScannerState copyWith({
    ScannerStatus? status,
    TattooModel? matchedTattoo,
    String? errorMessage,
    int? referenceImageCount,
  }) {
    return ScannerState(
      status: status ?? this.status,
      matchedTattoo: matchedTattoo,
      errorMessage: errorMessage,
      referenceImageCount: referenceImageCount ?? this.referenceImageCount,
    );
  }
}

/// Owns the scan loop's business logic: syncing tattoo references from
/// Supabase, feeding camera frames to the matcher engine, and triggering
/// audio playback on a confirmed match — completely decoupled from camera
/// widget lifecycle so it's testable without a real camera.
class ScannerController extends StateNotifier<ScannerState> {
  ScannerController() : super(const ScannerState()) {
    _bootstrap();
  }

  final _matcher = TattooMatcherEngine.instance;
  final _cache = LocalCacheService.instance;
  final _audio = AudioPlaybackService.instance;

  List<TattooModel> _knownTattoos = [];
  DateTime? _lastMatchTime;
  String? _lastMatchedTattooId;
  bool _isProcessingFrame = false;

  Future<void> _bootstrap() async {
    try {
      state = state.copyWith(status: ScannerStatus.syncingReferenceImages);
      await _syncTattoosAndBuildFeatureSets();
      state = state.copyWith(status: ScannerStatus.scanning);
    } catch (e) {
      // Fall back to whatever is cached locally rather than blocking the
      // scanner entirely just because the network sync failed.
      _knownTattoos = _cache.getAllCachedTattoos();
      if (_knownTattoos.isNotEmpty) {
        state = state.copyWith(
          status: ScannerStatus.scanning,
          referenceImageCount: _knownTattoos.length,
        );
      } else {
        state = state.copyWith(
          status: ScannerStatus.error,
          errorMessage:
              'Could not load tattoo library. Check your connection.',
        );
      }
    }
  }

  Future<void> _syncTattoosAndBuildFeatureSets() async {
    final remoteTattoos = await SupabaseService.instance.fetchAllTattoos();
    await _cache.replaceAllCachedTattoos(remoteTattoos);
    await _cache.setLastSyncedAt(DateTime.now());
    _knownTattoos = remoteTattoos;

    _matcher.clearAll();
    for (final tattoo in remoteTattoos) {
      try {
        final bytes = await _downloadBytes(tattoo.tattooImageUrl);
        await _matcher.registerReferenceImage(
          tattooId: tattoo.id,
          imageBytes: bytes,
        );
      } catch (_) {
        // Skip tattoos whose reference image fails to download — one bad
        // record shouldn't take down the whole scanner.
        continue;
      }
    }

    state = state.copyWith(referenceImageCount: _knownTattoos.length);
  }

  Future<Uint8List> _downloadBytes(String url) async {
    final response = await http.get(Uri.parse(url));
    if (response.statusCode != 200) {
      throw Exception('Failed to download $url (${response.statusCode})');
    }
    return response.bodyBytes;
  }

  /// Called by the camera widget with each throttled frame (JPEG bytes).
  Future<void> processFrame(Uint8List frameBytes) async {
    if (_isProcessingFrame) return;
    if (state.status != ScannerStatus.scanning &&
        state.status != ScannerStatus.matchFound) {
      return;
    }
    if (!_matcher.hasReferenceImages) return;

    _isProcessingFrame = true;
    try {
      final candidate = await _matcher.matchFrame(frameBytes);
      if (candidate == null) {
        _isProcessingFrame = false;
        return;
      }

      // Cooldown: don't keep re-triggering the same tattoo's audio while
      // it's still in frame.
      final now = DateTime.now();
      if (_lastMatchedTattooId == candidate.tattooId &&
          _lastMatchTime != null &&
          now.difference(_lastMatchTime!).inSeconds <
              AppConstants.matchCooldownSeconds) {
        _isProcessingFrame = false;
        return;
      }

      TattooModel? tattoo;
      for (final t in _knownTattoos) {
        if (t.id == candidate.tattooId) {
          tattoo = t;
          break;
        }
      }

      if (tattoo == null) {
        _isProcessingFrame = false;
        return;
      }

      _lastMatchTime = now;
      _lastMatchedTattooId = tattoo.id;

      state = state.copyWith(
        status: ScannerStatus.matchFound,
        matchedTattoo: tattoo,
      );

      // Play immediately — no popup, no confirmation, per spec.
      await _audio.playFromUrl(tattoo.audioUrl);

      // Return to active scanning after a short grace period so the UI
      // doesn't get stuck showing the "matched" banner forever.
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted && state.status == ScannerStatus.matchFound) {
          state = state.copyWith(status: ScannerStatus.scanning);
        }
      });
    } finally {
      _isProcessingFrame = false;
    }
  }

  Future<void> resync() => _syncTattoosAndBuildFeatureSets();

  @override
  void dispose() {
    _matcher.clearAll();
    super.dispose();
  }
}

final scannerControllerProvider =
    StateNotifierProvider<ScannerController, ScannerState>(
  (ref) => ScannerController(),
);
