import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;
import '../../../core/constants/app_constants.dart';
import '../providers/scanner_provider.dart';

/// Owns the camera lifecycle and pushes throttled, JPEG-encoded frames into
/// [ScannerController.processFrame]. The camera itself never shows a
/// capture button or shutter UI — per spec, recognition is fully automatic.
class TattooCameraView extends ConsumerStatefulWidget {
  const TattooCameraView({super.key});

  @override
  ConsumerState<TattooCameraView> createState() => _TattooCameraViewState();
}

class _TattooCameraViewState extends ConsumerState<TattooCameraView>
    with WidgetsBindingObserver {
  CameraController? _controller;
  bool _isStreaming = false;
  DateTime _lastFrameProcessedAt = DateTime.fromMillisecondsSinceEpoch(0);
  bool _busyEncoding = false;
  String? _initError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() => _initError = 'No camera available on this device.');
        return;
      }

      final backCamera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );

      final controller = CameraController(
        backCamera,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );

      await controller.initialize();
      if (!mounted) return;

      _controller = controller;
      await _startStreaming();
      setState(() {});
    } catch (e) {
      if (mounted) {
        setState(() => _initError = 'Camera failed to start: $e');
      }
    }
  }

  Future<void> _startStreaming() async {
    if (_controller == null || _isStreaming) return;
    _isStreaming = true;
    final minFrameGap = Duration(
      milliseconds: (1000 / AppConstants.scannerFramesPerSecond).round(),
    );

    await _controller!.startImageStream((CameraImage image) {
      final now = DateTime.now();
      if (_busyEncoding) return;
      if (now.difference(_lastFrameProcessedAt) < minFrameGap) return;
      _lastFrameProcessedAt = now;
      _handleFrame(image);
    });
  }

  Future<void> _handleFrame(CameraImage image) async {
    _busyEncoding = true;
    try {
      final jpegBytes = await _convertToJpeg(image);
      if (jpegBytes != null) {
        await ref
            .read(scannerControllerProvider.notifier)
            .processFrame(jpegBytes);
      }
    } catch (_) {
      // Drop malformed frames silently — the next frame will retry.
    } finally {
      _busyEncoding = false;
    }
  }

  /// Converts a YUV420/NV21 CameraImage into JPEG bytes the OpenCV matcher
  /// can decode. Run off the UI thread implicitly via the async gap; the
  /// actual pixel conversion is CPU-bound but bounded by our frame-rate
  /// throttle so it doesn't pile up.
  Future<List<int>?> _convertToJpeg(CameraImage image) async {
    try {
      final width = image.width;
      final height = image.height;

      final img.Image rgbImage = img.Image(width: width, height: height);

      final yPlane = image.planes[0];
      final uPlane = image.planes[1];
      final vPlane = image.planes[2];

      final yRowStride = yPlane.bytesPerRow;
      final uvRowStride = uPlane.bytesPerRow;
      final uvPixelStride = uPlane.bytesPerPixel ?? 1;

      for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
          final yIndex = y * yRowStride + x;
          final uvIndex =
              (y ~/ 2) * uvRowStride + (x ~/ 2) * uvPixelStride;

          final yVal = yPlane.bytes[yIndex];
          final uVal = uPlane.bytes[uvIndex];
          final vVal = vPlane.bytes[uvIndex];

          final r = (yVal + 1.370705 * (vVal - 128)).clamp(0, 255).toInt();
          final g = (yVal - 0.337633 * (uVal - 128) - 0.698001 * (vVal - 128))
              .clamp(0, 255)
              .toInt();
          final b = (yVal + 1.732446 * (uVal - 128)).clamp(0, 255).toInt();

          rgbImage.setPixelRgb(x, y, r, g, b);
        }
      }

      return img.encodeJpg(rgbImage, quality: 85);
    } catch (_) {
      return null;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;

    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      controller.stopImageStream();
      _isStreaming = false;
    } else if (state == AppLifecycleState.resumed) {
      _startStreaming();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_initError != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            _initError!,
            textAlign: TextAlign.center,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        ),
      );
    }

    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }

    return CameraPreview(controller);
  }
}
