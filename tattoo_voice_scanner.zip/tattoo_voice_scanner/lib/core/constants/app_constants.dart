/// App-wide constants.
///
/// IMPORTANT: The Supabase anon/publishable key below is safe to ship in a
/// client app — it is the public key meant for client-side use and is
/// useless without your project's Row Level Security (RLS) policies being
/// correctly configured. See supabase/schema.sql for the matching policies.
class AppConstants {
  AppConstants._();

  // ---------------------------------------------------------------------
  // Supabase
  // ---------------------------------------------------------------------
  static const String supabaseUrl = 'https://nzgzrfgtyfkgfmqwaqfe.supabase.co';
  static const String supabaseAnonKey =
      'sb_publishable_oh33P621kFxmtC8kGiBCWg_R5-nEDu1';

  static const String tattoosTable = 'tattoos';
  static const String tattooImagesBucket = 'tattoo-images';
  static const String tattooAudioBucket = 'tattoo-audio';

  // ---------------------------------------------------------------------
  // Hive local cache boxes
  // ---------------------------------------------------------------------
  static const String hiveTattooBox = 'tattoo_cache_box';
  static const String hiveSettingsBox = 'settings_box';
  static const String hiveDescriptorBox = 'tattoo_descriptor_box';

  // ---------------------------------------------------------------------
  // Scanner / matching tuning
  // ---------------------------------------------------------------------

  /// Minimum number of good ORB/AKAZE matches before we even attempt a
  /// homography check. Below this, two images are not considered a
  /// candidate match at all.
  static const int minGoodMatches = 12;

  /// Minimum number of RANSAC inliers (i.e. matches that agree with a single
  /// consistent homography) required to accept a match as "real". This is
  /// what filters out coincidental keypoint overlap between unrelated images.
  static const int minHomographyInliers = 10;

  /// Ratio test threshold (Lowe's ratio test) used when matching ORB/AKAZE
  /// descriptors with a KNN matcher. Lower = stricter.
  static const double loweRatioThreshold = 0.75;

  /// Re-process at most this many camera frames per second. Running ORB on
  /// every single frame from a 30/60fps camera stream is wasted work and
  /// drains battery — we throttle instead.
  static const int scannerFramesPerSecond = 4;

  /// Once a tattoo is recognized and its audio starts playing, ignore further
  /// matches for this many seconds so the same audio doesn't keep re-triggering
  /// while the tattoo is still in frame.
  static const int matchCooldownSeconds = 8;

  // ---------------------------------------------------------------------
  // Misc
  // ---------------------------------------------------------------------
  static const String appName = 'Tattoo Voice Scanner';
}
