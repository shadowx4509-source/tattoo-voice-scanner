import 'package:hive/hive.dart';

part 'tattoo_model.g.dart';

/// Mirrors the `tattoos` table in Supabase.
///
/// Stored locally in Hive (as the raw fields below, NOT the binary image)
/// so the scanner can list known tattoos and their audio/image URLs without
/// a network round-trip every time. The actual ORB/AKAZE descriptors
/// computed from `tattooImage` are cached separately in the descriptor box,
/// keyed by `id`, since recomputing keypoints from a downloaded JPEG on
/// every cold start would be wasteful.
@HiveType(typeId: 0)
class TattooModel extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String createdAt;

  @HiveField(2)
  final String tattooName;

  /// Public Supabase Storage URL for the reference tattoo image.
  @HiveField(3)
  final String tattooImageUrl;

  /// Public Supabase Storage URL for the linked audio file.
  @HiveField(4)
  final String audioUrl;

  @HiveField(5)
  final String shopName;

  @HiveField(6)
  final String userName;

  TattooModel({
    required this.id,
    required this.createdAt,
    required this.tattooName,
    required this.tattooImageUrl,
    required this.audioUrl,
    required this.shopName,
    required this.userName,
  });

  factory TattooModel.fromMap(Map<String, dynamic> map) {
    return TattooModel(
      id: map['id'] as String,
      createdAt: map['created_at']?.toString() ?? '',
      tattooName: map['tattoo_name'] as String? ?? '',
      tattooImageUrl: map['tattoo_image'] as String? ?? '',
      audioUrl: map['audio_url'] as String? ?? '',
      shopName: map['shop_name'] as String? ?? '',
      userName: map['user_name'] as String? ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'created_at': createdAt,
      'tattoo_name': tattooName,
      'tattoo_image': tattooImageUrl,
      'audio_url': audioUrl,
      'shop_name': shopName,
      'user_name': userName,
    };
  }

  TattooModel copyWith({
    String? tattooName,
    String? tattooImageUrl,
    String? audioUrl,
    String? shopName,
    String? userName,
  }) {
    return TattooModel(
      id: id,
      createdAt: createdAt,
      tattooName: tattooName ?? this.tattooName,
      tattooImageUrl: tattooImageUrl ?? this.tattooImageUrl,
      audioUrl: audioUrl ?? this.audioUrl,
      shopName: shopName ?? this.shopName,
      userName: userName ?? this.userName,
    );
  }
}
