// GENERATED CODE - DO NOT MODIFY BY HAND
// This file mirrors what `flutter pub run build_runner build` would produce
// for TattooModel. It is checked in so the project compiles immediately;
// if you change tattoo_model.dart's fields, regenerate with:
//   flutter pub run build_runner build --delete-conflicting-outputs

part of 'tattoo_model.dart';

class TattooModelAdapter extends TypeAdapter<TattooModel> {
  @override
  final int typeId = 0;

  @override
  TattooModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return TattooModel(
      id: fields[0] as String,
      createdAt: fields[1] as String,
      tattooName: fields[2] as String,
      tattooImageUrl: fields[3] as String,
      audioUrl: fields[4] as String,
      shopName: fields[5] as String,
      userName: fields[6] as String,
    );
  }

  @override
  void write(BinaryWriter writer, TattooModel obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.createdAt)
      ..writeByte(2)
      ..write(obj.tattooName)
      ..writeByte(3)
      ..write(obj.tattooImageUrl)
      ..writeByte(4)
      ..write(obj.audioUrl)
      ..writeByte(5)
      ..write(obj.shopName)
      ..writeByte(6)
      ..write(obj.userName);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TattooModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
