import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/app_constants.dart';
import '../models/tattoo_model.dart';

/// Thin wrapper around the Supabase client. Every Supabase call in the app
/// goes through here so auth/db/storage logic isn't scattered across
/// screens and providers.
class SupabaseService {
  SupabaseService._();
  static final SupabaseService instance = SupabaseService._();

  SupabaseClient get _client => Supabase.instance.client;
  static const _uuid = Uuid();

  /// Call once in main() before runApp().
  static Future<void> initialize() async {
    await Supabase.initialize(
      url: AppConstants.supabaseUrl,
      anonKey: AppConstants.supabaseAnonKey,
    );
  }

  // ---------------------------------------------------------------------
  // AUTH
  // ---------------------------------------------------------------------

  User? get currentUser => _client.auth.currentUser;
  bool get isLoggedIn => currentUser != null;

  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  Future<AuthResponse> signUp({
    required String email,
    required String password,
  }) {
    return _client.auth.signUp(email: email, password: password);
  }

  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) {
    return _client.auth.signInWithPassword(email: email, password: password);
  }

  Future<void> signOut() => _client.auth.signOut();

  /// Checks the `is_admin` flag stored in the user's app_metadata / a
  /// `profiles` table. See supabase/schema.sql — admin status is granted
  /// manually by you (the project owner) via the Supabase dashboard, not
  /// self-service, since this app has no "request admin access" flow.
  Future<bool> isCurrentUserAdmin() async {
    final user = currentUser;
    if (user == null) return false;
    try {
      final row = await _client
          .from('profiles')
          .select('is_admin')
          .eq('id', user.id)
          .maybeSingle();
      return row != null && row['is_admin'] == true;
    } catch (_) {
      return false;
    }
  }

  // ---------------------------------------------------------------------
  // DATABASE: tattoos table
  // ---------------------------------------------------------------------

  Future<List<TattooModel>> fetchAllTattoos() async {
    final rows = await _client
        .from(AppConstants.tattoosTable)
        .select()
        .order('created_at', ascending: false);
    return (rows as List)
        .map((row) => TattooModel.fromMap(row as Map<String, dynamic>))
        .toList();
  }

  Future<TattooModel> insertTattoo({
    required String tattooName,
    required String tattooImageUrl,
    required String audioUrl,
    required String shopName,
    required String userName,
  }) async {
    final row = await _client
        .from(AppConstants.tattoosTable)
        .insert({
          'tattoo_name': tattooName,
          'tattoo_image': tattooImageUrl,
          'audio_url': audioUrl,
          'shop_name': shopName,
          'user_name': userName,
        })
        .select()
        .single();
    return TattooModel.fromMap(row);
  }

  Future<TattooModel> updateTattoo(TattooModel tattoo) async {
    final row = await _client
        .from(AppConstants.tattoosTable)
        .update(tattoo.toMap())
        .eq('id', tattoo.id)
        .select()
        .single();
    return TattooModel.fromMap(row);
  }

  Future<void> deleteTattoo(String id) async {
    await _client.from(AppConstants.tattoosTable).delete().eq('id', id);
  }

  // ---------------------------------------------------------------------
  // STORAGE
  // ---------------------------------------------------------------------

  /// Uploads a local image file and returns its public URL.
  Future<String> uploadTattooImage(File file) async {
    final ext = file.path.split('.').last;
    final path = '${_uuid.v4()}.$ext';
    await _client.storage
        .from(AppConstants.tattooImagesBucket)
        .upload(path, file);
    return _client.storage
        .from(AppConstants.tattooImagesBucket)
        .getPublicUrl(path);
  }

  /// Uploads a local audio file and returns its public URL.
  Future<String> uploadTattooAudio(File file) async {
    final ext = file.path.split('.').last;
    final path = '${_uuid.v4()}.$ext';
    await _client.storage
        .from(AppConstants.tattooAudioBucket)
        .upload(path, file);
    return _client.storage
        .from(AppConstants.tattooAudioBucket)
        .getPublicUrl(path);
  }

  /// Deletes a previously uploaded file given its public URL, used when a
  /// tattoo record is edited (replacing the image/audio) or deleted.
  Future<void> deleteStorageFileByUrl(String publicUrl, String bucket) async {
    try {
      final marker = '/object/public/$bucket/';
      final idx = publicUrl.indexOf(marker);
      if (idx == -1) return;
      final path = publicUrl.substring(idx + marker.length);
      await _client.storage.from(bucket).remove([path]);
    } catch (_) {
      // Non-fatal: orphaned storage files can be cleaned up later, but we
      // never want a failed cleanup to block the user's edit/delete action.
    }
  }
}
