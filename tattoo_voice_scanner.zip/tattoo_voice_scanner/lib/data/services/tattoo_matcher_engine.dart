import 'dart:typed_data';
import 'package:opencv_dart/opencv_dart.dart' as cv;
import '../../core/constants/app_constants.dart';

/// Result of attempting to match a live camera frame against one known
/// tattoo's reference descriptors.
class MatchCandidate {
  final String tattooId;
  final int inlierCount;
  final double inlierRatio;

  MatchCandidate({
    required this.tattooId,
    required this.inlierCount,
    required this.inlierRatio,
  });
}

/// Precomputed keypoints/descriptors for one reference tattoo image, kept
/// in memory while the scanner is running.
class TattooFeatureSet {
  final String tattooId;
  final cv.VecKeyPoint keypoints;
  final cv.Mat descriptors;

  TattooFeatureSet({
    required this.tattooId,
    required this.keypoints,
    required this.descriptors,
  });
}

/// Wraps OpenCV ORB + AKAZE feature detection, descriptor matching, and
/// homography-based geometric verification.
///
/// Why two detectors: ORB is fast and works well on tattoos with strong
/// linework/contrast. AKAZE tends to do better on tattoos with finer
/// shading or lower contrast against skin. We run ORB first (cheap) and
/// only fall back to AKAZE for a candidate if ORB's match is borderline,
/// which keeps the average-case cost low without sacrificing the harder
/// cases the spec calls out (different lighting, distance, angle).
class TattooMatcherEngine {
  TattooMatcherEngine._();
  static final TattooMatcherEngine instance = TattooMatcherEngine._();

  final cv.ORB _orb = cv.ORB.create(nFeatures: 700);
  final cv.AKAZE _akaze = cv.AKAZE.create();
  final cv.BFMatcher _bfMatcher =
      cv.BFMatcher.create(type: cv.NORM_HAMMING);

  /// In-memory cache: tattooId -> precomputed ORB feature set for the
  /// reference image. Populated by [buildFeatureSetFromBytes] when the
  /// scanner starts (or when the synced tattoo list changes).
  final Map<String, TattooFeatureSet> _orbFeatureCache = {};
  final Map<String, TattooFeatureSet> _akazeFeatureCache = {};

  /// Decodes a reference tattoo image and computes both ORB and AKAZE
  /// descriptors for it, storing them in the in-memory cache keyed by id.
  /// Called once per tattoo after download, not per-frame.
  Future<void> registerReferenceImage({
    required String tattooId,
    required Uint8List imageBytes,
  }) async {
    final mat = cv.imdecode(imageBytes, cv.IMREAD_GRAYSCALE);

    final (orbKp, orbDesc) = _orb.detectAndCompute(mat, cv.Mat.empty());
    _orbFeatureCache[tattooId] = TattooFeatureSet(
      tattooId: tattooId,
      keypoints: orbKp,
      descriptors: orbDesc,
    );

    final (akazeKp, akazeDesc) = _akaze.detectAndCompute(mat, cv.Mat.empty());
    _akazeFeatureCache[tattooId] = TattooFeatureSet(
      tattooId: tattooId,
      keypoints: akazeKp,
      descriptors: akazeDesc,
    );

    mat.dispose();
  }

  void unregister(String tattooId) {
    _orbFeatureCache.remove(tattooId);
    _akazeFeatureCache.remove(tattooId);
  }

  void clearAll() {
    _orbFeatureCache.clear();
    _akazeFeatureCache.clear();
  }

  bool get hasReferenceImages => _orbFeatureCache.isNotEmpty;

  /// Runs one camera frame against every registered tattoo and returns the
  /// best geometrically-verified match, or null if nothing passed the
  /// homography inlier threshold.
  ///
  /// This is intentionally a "scan everything, keep the best" approach
  /// rather than stopping at the first candidate that clears the minimum
  /// bar — with a shop's tattoo library likely being small (tens, not
  /// thousands), the cost of checking all of them is negligible, and it
  /// avoids triggering the wrong audio when two tattoos share some
  /// keypoints but one is a much stronger match.
  Future<MatchCandidate?> matchFrame(Uint8List frameBytes) async {
    if (_orbFeatureCache.isEmpty) return null;

    final frameMat = cv.imdecode(frameBytes, cv.IMREAD_GRAYSCALE);
    final (frameKp, frameDesc) =
        _orb.detectAndCompute(frameMat, cv.Mat.empty());

    MatchCandidate? best;

    for (final entry in _orbFeatureCache.entries) {
      final tattooId = entry.key;
      final candidate = _tryMatch(
        refKp: entry.value.keypoints,
        refDesc: entry.value.descriptors,
        frameKp: frameKp,
        frameDesc: frameDesc,
      );

      if (candidate == null) continue;

      // Borderline ORB result: confirm (or reject) with AKAZE before
      // trusting it, since ORB can occasionally find a coincidental cluster
      // of matching corners on visually unrelated tattoos.
      final isBorderline = candidate.inlierCount <
          (AppConstants.minHomographyInliers * 1.5).round();

      MatchCandidate? confirmed = candidate;
      if (isBorderline) {
        final akazeSet = _akazeFeatureCache[tattooId];
        if (akazeSet != null) {
          final (akazeFrameKp, akazeFrameDesc) =
              _akaze.detectAndCompute(frameMat, cv.Mat.empty());
          confirmed = _tryMatch(
            refKp: akazeSet.keypoints,
            refDesc: akazeSet.descriptors,
            frameKp: akazeFrameKp,
            frameDesc: akazeFrameDesc,
          );
        } else {
          confirmed = null;
        }
      }

      if (confirmed != null) {
        confirmed = MatchCandidate(
          tattooId: tattooId,
          inlierCount: confirmed.inlierCount,
          inlierRatio: confirmed.inlierRatio,
        );
        if (best == null || confirmed.inlierCount > best.inlierCount) {
          best = confirmed;
        }
      }
    }

    frameMat.dispose();
    return best;
  }

  /// Core matching routine shared by the ORB and AKAZE passes:
  /// 1. KNN match descriptors (k=2)
  /// 2. Lowe's ratio test to keep only distinctive matches
  /// 3. Homography fit via RANSAC to verify the matches agree on one
  ///    consistent perspective transform (this is what rejects random
  ///    keypoint coincidences and confirms "this really is the same tattoo,
  ///    just rotated/tilted/at a different distance")
  MatchCandidate? _tryMatch({
    required cv.VecKeyPoint refKp,
    required cv.Mat refDesc,
    required cv.VecKeyPoint frameKp,
    required cv.Mat frameDesc,
  }) {
    if (refDesc.rows == 0 || frameDesc.rows == 0) return null;

    final knnMatches = _bfMatcher.knnMatch(refDesc, frameDesc, k: 2);

    final goodMatches = <cv.DMatch>[];
    for (final pair in knnMatches) {
      if (pair.length < 2) continue;
      final m = pair[0];
      final n = pair[1];
      if (m.distance < AppConstants.loweRatioThreshold * n.distance) {
        goodMatches.add(m);
      }
    }

    if (goodMatches.length < AppConstants.minGoodMatches) return null;

    final srcPts = goodMatches
        .map((m) => refKp[m.queryIdx].pt)
        .toList();
    final dstPts = goodMatches
        .map((m) => frameKp[m.trainIdx].pt)
        .toList();

    final srcMat = cv.Mat.fromList(
      srcPts.map((p) => [p.x, p.y]).toList(),
    );
    final dstMat = cv.Mat.fromList(
      dstPts.map((p) => [p.x, p.y]).toList(),
    );

    // NOTE: findHomography returns the homography Mat directly; the
    // inlier mask is written into the `mask` Mat passed in (an
    // out-parameter), not returned as part of a tuple. Confirmed against
    // the dartcv4/opencv_dart source for the calib3d module.
    final mask = cv.Mat.empty();
    final homography = cv.findHomography(
      srcMat,
      dstMat,
      method: cv.RANSAC,
      ransacReprojThreshold: 5.0,
      mask: mask,
    );

    if (homography.isEmpty) {
      srcMat.dispose();
      dstMat.dispose();
      mask.dispose();
      homography.dispose();
      return null;
    }

    int inliers = 0;
    for (int i = 0; i < mask.rows; i++) {
      if (mask.at<int>(i, 0) != 0) inliers++;
    }

    srcMat.dispose();
    dstMat.dispose();
    homography.dispose();
    mask.dispose();

    if (inliers < AppConstants.minHomographyInliers) return null;

    return MatchCandidate(
      tattooId: '', // filled in by caller context; see matchFrame loop below
      inlierCount: inliers,
      inlierRatio: inliers / goodMatches.length,
    );
  }
}
