import 'dart:typed_data';
import 'package:hive_flutter/hive_flutter.dart';
import '../../core/constants/app_constants.dart';
import '../models/tattoo_model.dart';

/// Local cache so the scanner works against the last-synced tattoo list
/// even with a flaky connection, and so we don't recompute ORB/AKAZE
/// descriptors from a downloaded image every time the app opens.
class LocalCacheService {
  LocalCacheService._();
  static final LocalCacheService instance = LocalCacheService._();

  late Box<TattooModel> _tattooBox;
  late Box _settingsBox;

  /// Raw descriptor bytes per tattoo id. Stored as a plain (non-typed) box
  /// since the byte layout is opaque to Hive — it's whatever
  /// cv.Mat(...).toBytes() / fromBytes() round-trips through OpenCV.
  late Box _descriptorBox;

  Future<void> initialize() async {
    await Hive.initFlutter();
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(TattooModelAdapter());
    }
    _tattooBox =
        await Hive.openBox<TattooModel>(AppConstants.hiveTattooBox);
    _settingsBox = await Hive.openBox(AppConstants.hiveSettingsBox);
    _descriptorBox = await Hive.openBox(AppConstants.hiveDescriptorBox);
  }

  // ---------------------------------------------------------------------
  // Tattoo metadata cache
  // ---------------------------------------------------------------------

  List<TattooModel> getAllCachedTattoos() => _tattooBox.values.toList();

  Future<void> replaceAllCachedTattoos(List<TattooModel> tattoos) async {
    await _tattooBox.clear();
    for (final t in tattoos) {
      await _tattooBox.put(t.id, t);
    }
  }

  Future<void> upsertCachedTattoo(TattooModel tattoo) =>
      _tattooBox.put(tattoo.id, tattoo);

  Future<void> deleteCachedTattoo(String id) async {
    await _tattooBox.delete(id);
    await _descriptorBox.delete(id);
  }

  // ---------------------------------------------------------------------
  // Feature descriptor cache (raw bytes, keyed by tattoo id)
  // ---------------------------------------------------------------------

  Uint8List? getCachedDescriptors(String tattooId) {
    final raw = _descriptorBox.get(tattooId);
    if (raw == null) return null;
    return Uint8List.fromList(List<int>.from(raw as List));
  }

  Future<void> setCachedDescriptors(String tattooId, Uint8List bytes) {
    return _descriptorBox.put(tattooId, bytes.toList());
  }

  Future<void> clearDescriptorCache() => _descriptorBox.clear();

  // ---------------------------------------------------------------------
  // Settings (theme mode, last sync timestamp, etc.)
  // ---------------------------------------------------------------------

  String? get themeMode => _settingsBox.get('theme_mode') as String?;
  Future<void> setThemeMode(String mode) =>
      _settingsBox.put('theme_mode', mode);

  DateTime? get lastSyncedAt {
    final iso = _settingsBox.get('last_synced_at') as String?;
    return iso == null ? null : DateTime.tryParse(iso);
  }

  Future<void> setLastSyncedAt(DateTime time) =>
      _settingsBox.put('last_synced_at', time.toIso8601String());
}
