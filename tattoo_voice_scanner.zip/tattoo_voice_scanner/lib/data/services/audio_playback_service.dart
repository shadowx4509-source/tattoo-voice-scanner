import 'package:just_audio/just_audio.dart';

/// Plays the audio linked to a recognized tattoo. Kept as a single
/// long-lived player instance so starting a new tattoo's audio cleanly
/// stops whatever was playing before.
class AudioPlaybackService {
  AudioPlaybackService._();
  static final AudioPlaybackService instance = AudioPlaybackService._();

  final AudioPlayer _player = AudioPlayer();

  String? _currentlyPlayingUrl;
  String? get currentlyPlayingUrl => _currentlyPlayingUrl;

  Stream<PlayerState> get playerStateStream => _player.playerStateStream;

  /// Starts playback immediately — no confirmation, no popup, per spec.
  Future<void> playFromUrl(String url) async {
    if (_currentlyPlayingUrl == url && _player.playing) {
      // Already playing this exact tattoo's audio — don't restart it.
      return;
    }
    await _player.stop();
    _currentlyPlayingUrl = url;
    await _player.setUrl(url);
    await _player.play();
  }

  Future<void> stop() async {
    await _player.stop();
    _currentlyPlayingUrl = null;
  }

  Future<void> dispose() => _player.dispose();
}
