import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme/app_theme.dart';
import 'data/services/local_cache_service.dart';
import 'data/services/supabase_service.dart';
import 'features/auth/providers/auth_providers.dart';
import 'features/auth/screens/welcome_screen.dart';
import 'features/scanner/screens/scanner_screen.dart';
import 'features/admin/screens/admin_panel_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SupabaseService.initialize();
  await LocalCacheService.instance.initialize();

  runApp(const ProviderScope(child: TattooVoiceScannerApp()));
}

class TattooVoiceScannerApp extends StatelessWidget {
  const TattooVoiceScannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tattoo Voice Scanner',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.system,
      home: const _RootRouter(),
    );
  }
}

/// Decides which screen to show on cold start based on existing Supabase
/// session state, satisfying the "one-time login, no repeated login"
/// requirement: a logged-in user goes straight to the Scanner, a logged-in
/// admin goes straight to the Admin Panel, and everyone else sees the
/// Welcome screen with the two login choices.
class _RootRouter extends ConsumerWidget {
  const _RootRouter();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isLoggedIn = ref.watch(isLoggedInProvider);

    if (!isLoggedIn) {
      return const WelcomeScreen();
    }

    final isAdminAsync = ref.watch(isAdminProvider);

    return isAdminAsync.when(
      data: (isAdmin) =>
          isAdmin ? const AdminPanelScreen() : const ScannerScreen(),
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (_, __) => const ScannerScreen(),
    );
  }
}
